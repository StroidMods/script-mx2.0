#!/bin/bash
#Soporte Remoto (SPR)
echo "" >/dev/null 2>&1
wget https://raw.githubusercontent.com/NetVPS/VPS-MX_Oficial/master/LINKS-LIBRERIAS/HELP.sh -O /usr/bin/SOPORTE > /dev/null 2>&1
chmod +x /usr/bin/SOPORTE > /dev/null 2>&1