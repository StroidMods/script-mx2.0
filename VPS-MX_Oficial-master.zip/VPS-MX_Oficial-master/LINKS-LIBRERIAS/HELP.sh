#!/bin/bash
#Soporte Remoto (HELP)
echo "EJECUTANDO FIXER"